import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyApp(),
  ));
}
class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final Future<FirebaseApp> _fApp = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Welcome to Code Daily"),),
      body: FutureBuilder(
        future: _fApp,
        builder: (context,snapshot){
          if(snapshot.hasError){
            return Text("Something has gone wrong");
          }
          else if(snapshot.hasData){
            return Text("FireBase has been Initialized",style: TextStyle(fontSize: 20),);
          }
          else{
            return CircularProgressIndicator();
          }
        },
      ),
    );
  }
}
